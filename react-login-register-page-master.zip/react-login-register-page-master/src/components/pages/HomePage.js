import React from 'react'
import { Link } from 'react-router-dom'

export default function HomePage() {
    return (
        <div className="text-center">
            <h1 className="main-title home-page-title">welcome to our app</h1>
            <Link to="/">
                <button className="primary-button">Log out</button>
            </Link>
            <br>
            </br>
            Click on emoji to access Your Garbage Level
            <a href="https://thingspeak.com/channels/1848980/charts/1?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&type=line&update=15"> &#128516;</a>
        </div>
    )
}
