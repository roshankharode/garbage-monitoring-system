package com.Loan.Portal.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Loan.Portal.models.Customer;
import com.Loan.Portal.models.Loan;
import com.Loan.Portal.security.services.CustomerServiceImplementation;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class CustomerController {
	
	@Autowired 
	private CustomerServiceImplementation customerService;
	
	//post Method
			@PostMapping("/loanapplication/{loanid}")
			public Customer addLoanApplication(@Valid @PathVariable int loanid, @RequestBody Customer customer) {
				return customerService.addLoanApplication(loanid, customer);
			}
			
			@GetMapping("/loanapplication/{id}")
			public Loan getloanbyid(@PathVariable int id){
				return customerService.getloanbyid(id);
			}
			
			//Get Method
			@GetMapping("/loanapplications")
			public List<Customer> getAllLoanApplication(){
				return customerService.showAllLoanApplication();
			}
			
			@PutMapping("/acceptStatus/{id}")
			public String acceptStatusByCustId(@PathVariable int id) {
				customerService.AcceptLoan(id);
				return "Loan Accepted";
			}
			@PutMapping("/rejectStatus/{id}")
			public String rejectStatusByCustId(@PathVariable int id) {
				customerService.RejectLoan(id);
				return "Loan Rejected";
			}
}
