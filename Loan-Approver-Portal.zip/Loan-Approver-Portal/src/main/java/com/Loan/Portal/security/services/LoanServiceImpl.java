package com.Loan.Portal.security.services;

import java.util.List;
import java.util.Optional;

import javax.naming.NameNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Loan.Portal.Exceptions.IdNotFoundException;
import com.Loan.Portal.Exceptions.LoanNotFoundException;
import com.Loan.Portal.models.Loan;
import com.Loan.Portal.repository.LoanRepository;

@Service
public class LoanServiceImpl {

	@Autowired
	private LoanRepository loanRepository;

	public Loan addLoanPlan(Loan loan) {
		return loanRepository.save(loan);
	}

	public Loan updateLoanPlan(int id,Loan loan) throws LoanNotFoundException {
		Optional<Loan> existingLoanOptional = loanRepository.findById(id);
		Loan updateLoan = existingLoanOptional.get();
		updateLoan.setLoanName(loan.getLoanName());
		updateLoan.setAmount(loan.getAmount());
		updateLoan.setNoOfEMI(loan.getNoOfEMI());
		updateLoan.setInterestRate(loan.getInterestRate());
		return loanRepository.save(updateLoan);
	}

	public String deleteLoanPlanById(Integer loanId) throws IdNotFoundException {
		loanRepository.findById(loanId)
				.orElseThrow(() -> new IdNotFoundException("No loan plan found with Id: " + loanId));
		loanRepository.deleteById(loanId);
		return "Loan plan is deleted successfully";
	}

	public List<Loan> getLoanPlanByName(String loanName) throws NameNotFoundException {
		List<Loan> foundLoanPlanByName = this.loanRepository.findByLoanName(loanName);
		if (foundLoanPlanByName.isEmpty())
			throw new NameNotFoundException("No loan plan found with loan name: " + loanName);

		return foundLoanPlanByName;
	}

	public List<Loan> getAllLoanPlan() {
		return loanRepository.findAll();
	}

	
	
	public Loan getLoanPlanByid(int id) {
		return loanRepository.findById(id).get();
	}

}
