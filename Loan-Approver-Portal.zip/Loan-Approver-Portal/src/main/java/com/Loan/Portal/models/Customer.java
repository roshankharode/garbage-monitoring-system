package com.Loan.Portal.models;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Customer")
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private Integer customerId;
	@Column
	private String custName;
	@Column
	private LocalDate dateOfBirth;
	@Column
	private Integer age;
	@Column
	private Long mobileNumber;
	@Column
	private Long accountNo;
	@Column
	private String custEmailId;
	@Column
	private Long salary;
	@Column
	private Long aadharCard;
	@Column
	private String status;
	@Column
	private int loanid;
	@Column
	private String  loanName;
	
	
	public Customer() {
		super();
	}


	public Customer(Integer customerId, String custName, LocalDate dateOfBirth, Integer age, Long mobileNumber,
			Long accountNo, String custEmailId, Long salary, Long aadharCard, String status, int loanid,
			String loanName) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.dateOfBirth = dateOfBirth;
		this.age = age;
		this.mobileNumber = mobileNumber;
		this.accountNo = accountNo;
		this.custEmailId = custEmailId;
		this.salary = salary;
		this.aadharCard = aadharCard;
		this.status = status;
		this.loanid = loanid;
		this.loanName = loanName;
	}


	public Integer getCustomerId() {
		return customerId;
	}


	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public Integer getAge() {
		return age;
	}


	public void setAge(Integer age) {
		this.age = age;
	}


	public Long getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public Long getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}


	public String getCustEmailId() {
		return custEmailId;
	}


	public void setCustEmailId(String custEmailId) {
		this.custEmailId = custEmailId;
	}


	public Long getSalary() {
		return salary;
	}


	public void setSalary(Long salary) {
		this.salary = salary;
	}


	public Long getAadharCard() {
		return aadharCard;
	}


	public void setAadharCard(Long aadharCard) {
		this.aadharCard = aadharCard;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public int getLoanid() {
		return loanid;
	}


	public void setLoanid(int loanid) {
		this.loanid = loanid;
	}


	public String getLoanName() {
		return loanName;
	}


	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}


}
