package com.Loan.Portal.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "LoanPlans")
public class Loan {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer loanId;

	@NotBlank(message = "Name cannot be blank")
	@Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters long.")
	private String loanName;

	@NotNull
	private Integer amount;
	
	@NotNull
	private Integer noOfEMI;

	@NotNull
	private Integer interestRate;

	public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Loan(Integer loanId,
			@NotBlank(message = "Name cannot be blank") @Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters long.") String loanName,
			@NotNull Integer amount, @NotNull Integer noOfEMI, @NotNull Integer interestRate) {
		super();
		this.loanId = loanId;
		this.loanName = loanName;
		this.amount = amount;
		this.noOfEMI = noOfEMI;
		this.interestRate = interestRate;
	}

	public Integer getLoanId() {
		return loanId;
	}

	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}

	public String getLoanName() {
		return loanName;
	}

	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public Integer getNoOfEMI() {
		return noOfEMI;
	}

	public void setNoOfEMI(Integer noOfEMI) {
		this.noOfEMI = noOfEMI;
	}

	public Integer getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Integer interestRate) {
		this.interestRate = interestRate;
	}
	
}
