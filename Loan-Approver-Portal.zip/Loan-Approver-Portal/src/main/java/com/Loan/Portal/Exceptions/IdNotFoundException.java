package com.Loan.Portal.Exceptions;

public class IdNotFoundException extends Exception {
	
	public IdNotFoundException(String msg) {
		super(msg);
	}

}
