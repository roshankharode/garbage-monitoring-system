package com.Loan.Portal.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Loan.Portal.models.Customer;
import com.Loan.Portal.models.Loan;
import com.Loan.Portal.repository.CustomerRepository;
import com.Loan.Portal.repository.LoanRepository;

@Service
public class CustomerServiceImplementation {

	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	LoanRepository loanRepository;

	public Customer addLoanApplication(Integer loanId, Customer customer) {
		Customer cust = new Customer();
		cust.setAadharCard(customer.getAadharCard());
		cust.setAccountNo(customer.getAccountNo());
		cust.setAge(customer.getAge());
		cust.setCustEmailId(customer.getCustEmailId());
		cust.setCustName(customer.getCustName());
		cust.setCustomerId(customer.getCustomerId());
		cust.setDateOfBirth(customer.getDateOfBirth());
		cust.setMobileNumber(customer.getMobileNumber());
		cust.setSalary(customer.getSalary());
		cust.setStatus("Pending...");
		Loan loan = loanRepository.findById(loanId).get();
		if (loan != null) {
			cust.setLoanid(loanId);
			cust.setLoanName(loan.getLoanName());
		}
		return customerRepository.save(cust);
	}

	public Loan getloanbyid(int id) {
		return loanRepository.findById(id).get();
	}

	public void AcceptLoan(int id) {
		Customer cust = customerRepository.findById(id).get();
		if (cust != null) {
			cust.setStatus("Accepted");
		}
		customerRepository.save(cust);
	}
	public void RejectLoan(int id) {
		Customer cust = customerRepository.findById(id).get();
		if (cust != null) {
			cust.setStatus("Rejected");
		}
		customerRepository.save(cust);
	}

	public List<Customer> showAllLoanApplication() {
		return customerRepository.findAll();
	}

}
