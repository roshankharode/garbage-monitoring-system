package com.Loan.Portal.Exceptions;

public class LoanNotFoundException extends Exception {


	public LoanNotFoundException(String msg) {
		super(msg);
	}

}
