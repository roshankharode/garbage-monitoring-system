package com.Loan.Portal.controllers;

import java.util.List;

import javax.naming.NameNotFoundException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Loan.Portal.Exceptions.IdNotFoundException;
import com.Loan.Portal.Exceptions.LoanNotFoundException;
import com.Loan.Portal.models.Loan;
import com.Loan.Portal.security.services.LoanServiceImpl;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class LoanController {
	
	@Autowired
	private LoanServiceImpl loanService;
	
	//post Methods
		@PostMapping("/loanplan")
		public Loan addLoanPlan(@Valid @RequestBody Loan loan) {
			return loanService.addLoanPlan(loan);
		}
		
		
		//Get Methods
		@GetMapping("/loanplans")
		public List<Loan> getAllLoanPlan(){
			return loanService.getAllLoanPlan();
		}
		 

		 @GetMapping("/loanname/{loanname}")
		 public List<Loan> getLoanByName(@Valid @PathVariable("loanname") String loanName) throws NameNotFoundException {
			 return loanService.getLoanPlanByName(loanName);
		 }
		 
		 
		 @GetMapping("/loan/{id}")
		 public Loan getLoanByName(@PathVariable int id) throws NameNotFoundException {
			 return loanService.getLoanPlanByid(id);
		 } 
		 
		 //Put Method
		 @PutMapping("/modifyloan/{id}")
			public Loan updateLoanPlan(@Valid @PathVariable int id,  @RequestBody Loan loan)  throws LoanNotFoundException {
			 return loanService.updateLoanPlan(id,loan);
		 }
		 
		 //Delete Method
		 @DeleteMapping("/loan/{loanid}")
		 public String deleteLoanById(@Valid @PathVariable("loanid") Integer loanId) throws IdNotFoundException{
			 return loanService.deleteLoanPlanById(loanId);
		 }

}
