package com.LibraryManegementSystem.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
public class DamagedBooks {

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int damagedid;

	@OneToOne
	@Cascade(CascadeType.ALL)
	private Books books;

	@Column
	private int quantity;

	@Column
	private String description;

	@Column String Status;
	
	public DamagedBooks() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DamagedBooks(int damagedid, Books books, int quantity, String description, String status) {
		super();
		this.damagedid = damagedid;
		this.books = books;
		this.quantity = quantity;
		this.description = description;
		Status = status;
	}

	public int getDamagedid() {
		return damagedid;
	}

	public void setDamagedid(int damagedid) {
		this.damagedid = damagedid;
	}

	public Books getBooks() {
		return books;
	}

	public void setBooks(Books books) {
		this.books = books;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

}
