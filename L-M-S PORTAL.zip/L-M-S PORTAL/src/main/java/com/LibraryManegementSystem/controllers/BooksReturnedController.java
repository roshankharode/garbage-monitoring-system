package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.models.BooksReturned;
import com.LibraryManegementSystem.security.services.BooksReturnedService;

@RestController
@CrossOrigin(origins = "*", maxAge = 9000)
@RequestMapping("/api/test")
public class BooksReturnedController {

	@Autowired
	BooksReturnedService booksreturnedservice;

	@GetMapping("/getreturnedbooks")
	private List<BooksReturned> viewReturnedBooksList() {
		return viewReturnedBooksList();
	}

	@PostMapping("/postreturnedBooks")
	private int returnBook(@RequestBody BooksReturned returned) {
		return booksreturnedservice.returnBook(returned);
	}

	@PutMapping("/putreturnedBooks")
	private int updateReturnedBookDetails(@RequestBody BooksReturned booksReturned) {
		return booksreturnedservice.updateReturnedBookDetails(booksReturned);

	}
}
