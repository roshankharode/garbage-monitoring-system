package com.LibraryManegementSystem.payload.request;

import javax.validation.constraints.NotBlank;

public class LoginRequest {
	@NotBlank
	private String firstName;

	@NotBlank
	private String password;

	public String getFirstName() {
		return firstName;
	}

	public void setUsername(String firstName) {
		this.firstName = firstName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
