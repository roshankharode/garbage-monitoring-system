package com.LibraryManegementSystem.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryManegementSystem.models.DamagedBooks;

@Repository
public interface DamagedBooksRepository extends CrudRepository<DamagedBooks, Integer> {


}
