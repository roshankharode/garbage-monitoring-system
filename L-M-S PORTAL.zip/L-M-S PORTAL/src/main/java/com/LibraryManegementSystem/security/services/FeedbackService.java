package com.LibraryManegementSystem.security.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.Exception.FeedbackNotFoundException;
import com.LibraryManegementSystem.models.Feedback;
import com.LibraryManegementSystem.models.User;
import com.LibraryManegementSystem.repository.FeedbackRepository;
import com.LibraryManegementSystem.repository.UserRepository;

@Service
public class FeedbackService {

	@Autowired
	private UserRepository urepo;
	
	@Autowired
	private FeedbackRepository repo;

	public int writeFeedback(Long id, Feedback feedback) {
		User u = urepo.findById(id).get();
		
		if (u==null) {
			return 0;
		}else {
		LocalDate date = LocalDate.now();
		Feedback feedback2 = new Feedback();
//		feedback2.setUser(id);
		feedback2.setComments("Unseen");
		feedback2.setFeedbackDate(date);
		feedback2.setRating(feedback.getRating());
		feedback2.setDescription(feedback.getDescription());
		repo.save(feedback2);
		return 1;
		}
	}

	public int updateFeedback(Long id, Feedback feedback) {
		Feedback feedback2 = repo.findById(id).get();
		feedback2.setComments(feedback.getComments());

		try {
			repo.save(feedback2);
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public Feedback getfeedbackbyid(Long id) throws FeedbackNotFoundException {
		Feedback feedback = repo.findByUser_id(id);
		return feedback;

	}

	public List<Feedback> viewFeedbackList() {
		List<Feedback> lst = null;
		try {
			lst = (List<Feedback>) repo.findAll();
			return lst;
		} catch (Exception e) {
			return lst;
		}
	}

	public FeedbackService(FeedbackRepository repo) {
		super();
		this.repo = repo;
	}
}
