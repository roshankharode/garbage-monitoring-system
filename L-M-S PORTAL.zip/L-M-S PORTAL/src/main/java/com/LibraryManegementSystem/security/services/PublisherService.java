package com.LibraryManegementSystem.security.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.Exception.PublisherNotFoundException;
import com.LibraryManegementSystem.models.Publishers;
import com.LibraryManegementSystem.repository.PublisherRepository;

@Service
public class PublisherService {
	private static final Logger log = LoggerFactory.getLogger(PublisherService.class);

	@Autowired
	private PublisherRepository repo;

	public int addPublisher(Publishers publisher) {
		log.info("Adding Publisher...");
		try {
			repo.save(publisher);
			log.info("Publisher Added!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public int updatePublisherDetails(Publishers publisher) {
		log.info("Updating Publisher Details...");
		try {
			repo.save(publisher);
			log.info("Publisher Details Updated!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public int removePublisher(int publisherId) throws PublisherNotFoundException {
		log.info("Removing Publisher...");
		try {
			repo.deleteById(publisherId);
			log.info("Publisher R");
			return 1;
		} catch (Exception e) {
			throw new PublisherNotFoundException("Publisher does not exist");
		}
	}

	public Publishers viewPublishersById(int publisherId) throws PublisherNotFoundException {
		Publishers p = null;
		try {
			p = repo.findById(publisherId).get();
			log.info("Fetched Publisher!!");
			return p;
		} catch (Exception e) {
			throw new PublisherNotFoundException("Publisher does not exist");
		}
	}

	public List<Publishers> viewPublishersList() {
		List<Publishers> lst = null;
		try {
			log.info("Fetching Publisher Details...");
			lst = (List<Publishers>) repo.findAll();
			log.info("Publisher Details Fetched!!");
			return lst;
		} catch (Exception e) {

			return lst;
		}
	}

	public PublisherService(PublisherRepository repo) {
		super();
		this.repo = repo;
	}
}
