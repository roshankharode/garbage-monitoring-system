package com.LMS.LibraryManagementSystem.ServiceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.annotation.Rollback;

import com.LibraryManegementSystem.Exception.BookNotFoundException;
import com.LibraryManegementSystem.models.Books;
import com.LibraryManegementSystem.repository.BookRepository;
import com.LibraryManegementSystem.security.services.BooksService;

@ExtendWith(MockitoExtension.class)
class BooksTest {

	@Mock
	private BookRepository repo;

	private BooksService service;

	@BeforeEach
	void setUp() {
		this.service = new BooksService(this.repo);
	}

	@Test
	@Order(1)
	@Rollback(false)
	void viewAllBooksTest() throws BookNotFoundException {
		service.viewAllBooks();
		verify(repo).findAll();
	}

	@Test
	@Order(2)
	@Rollback(false)
	void searchBookBySubjectTest() throws BookNotFoundException {
		service.searchBookBySubject("test");
		verify(repo).findBySubject("test");
	}

	@Test
	@Order(3)
	@Rollback(false)
	void searchBookByTitleTest() throws BookNotFoundException {
		service.searchBookByTitle("test1");
		verify(repo).findByTitle("test1");
	}

	@Test
	@Order(4)
	@Rollback(false)
	void removeBookTest() {
		try {
			service.removeBook(11);
		} catch (BookNotFoundException e) {
			e.printStackTrace();
		}
		verify(repo).deleteById(11);
	}

	@Test
	@Order(5)
	@Rollback(false)
	void addBookTest() {
		Books book = new Books(1,"java","tech","james","sun",2012,"131534534",13,"21");
		service.addBook(book);
		assertEquals(book.getPublisher(), "sun");
	}


}
