package com.LMS.LibraryManagementSystem.ServiceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.annotation.Rollback;

import com.LibraryManegementSystem.Exception.AuthorNotFoundException;
import com.LibraryManegementSystem.models.Author;
import com.LibraryManegementSystem.repository.AuthorRepository;
import com.LibraryManegementSystem.security.services.AuthorService;

@ExtendWith(MockitoExtension.class)
class AuthorTest {
	@Mock
	AuthorRepository repo;

	private AuthorService service;

	@BeforeEach
	void setUp() {
		this.service = new AuthorService(this.repo);
	}

	@Test
	@Order(1)
	@Rollback(false)
	void addAuthorDetailsTest() throws AuthorNotFoundException {
		Author author = new Author(1, "Roshan", "Kharode", "roshan@gmail.com", "7719068128");
		service.addAuthorDetails(author);
		assertEquals(author.getContactno(), "7719068128");
	}

	@Test
	@Order(2)
	@Rollback(false)
	void updateAuthorDetailsTest() throws AuthorNotFoundException {
		Author author = new Author(2, "Roshan", "Kharode", "roshan@gmail.com", "7719068128");
		service.addAuthorDetails(author);
		assertEquals(author.getLastName(), "Kharode");
	}

	@Test
	@Order(3)
	@Rollback(false)
	void deleteAuthorDetailsTest() throws AuthorNotFoundException {
		service.deleteAuthorDetails(2);
		verify(repo).deleteById(2);
	}

	@Test
	@Order(4)
	@Rollback(false)
	void viewAuthorListTest() {
		service.viewAuthorList();
		verify(repo).findAll();
	}

	@Test
	@Order(5)
	@Rollback(false)
	void viewAuthorByIdTest() throws AuthorNotFoundException {
		service.viewAuthorById(3);
		verify(repo).findById(3);
	}
}
