package com.LibraryManegementSystem.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryManegementSystem.models.SuggestedBooks;

@Repository
public interface SuggestedBooksRepository extends CrudRepository<SuggestedBooks, Integer> {

}