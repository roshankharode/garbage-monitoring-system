package com.LibraryManegementSystem.security.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.Exception.BookNotFoundException;
import com.LibraryManegementSystem.models.Books;
import com.LibraryManegementSystem.repository.BookRepository;
import com.LibraryManegementSystem.repository.BooksOrderRepository;

@Service
public class BooksService {
	private static final Logger log = LoggerFactory.getLogger(BooksService.class);
	@Autowired
	private BookRepository repo;
	
	@Autowired
	private BooksOrderRepository borepo;
	
	public int addBook(Books book) {
		log.info("Adding Book...");
		try {
			repo.save(book);
			log.info("Book Added!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public int updateBookDetails(int bookid, Books book) throws BookNotFoundException {
		Books books = repo.findById(bookid)
				.orElseThrow(() -> new BookNotFoundException("Book not exist with id :" + bookid));

		books.setAuthor(book.getAuthor());
		books.setIsbn_code(book.getIsbn_code());
		books.setPublished_year(book.getPublished_year());
		books.setTitle(book.getTitle());
		books.setSubject(book.getSubject());
		books.setShelf_details(book.getShelf_details());
		books.setQuantity(book.getQuantity());
		books.setPublisher(book.getPublisher());

		repo.save(books);
		log.info("Book Details Updated!!");
		return 1;
	}

	public int removeBook(int bookId) throws BookNotFoundException {
		
		borepo.deleteByBooks_Bookid(bookId);
		log.info("Cancelling Book...");
		try {
			repo.deleteById(bookId);
			log.info("Book Cancelled");
			return 1;
		} catch (Exception e) {
			throw new BookNotFoundException("Books Not Found");
		}
	}

	public List<Books> searchBookByTitle(String keyword) throws BookNotFoundException {
		log.info("Searching Book for title " + keyword + "...");
		try {
			List<Books> books = repo.findByTitle(keyword);
			log.info("Book Found!!");
			return books;
		} catch (Exception e) {
			throw new BookNotFoundException("Book Title: " + keyword + " does not exist");
		}
	}

	public Books getbyid(int bookid) {
	   Books b = null;
		b =  repo.findById(bookid).get();
		return b;
	}

	public List<Books> searchBookBySubject(String keyword) throws BookNotFoundException {
		log.info("Searching Book for Subject " + keyword + "...");
		try {
			List<Books> books = repo.findBySubject(keyword);
			log.info("Book Found!!");
			return books;
		} catch (Exception e) {
			throw new BookNotFoundException("Book Subject: " + keyword + " does not exist");
		}
	}

	public List<Books> viewAllBooks() throws BookNotFoundException {
		List<Books> b = null;
		try {
			b = (List<Books>) repo.findAll();
			log.info("Books Fetched!!");
			return b;
		} catch (Exception e) {
			throw new BookNotFoundException("No Book to list");
		}
	}

	public BooksService(BookRepository repo) {
		super();
		this.repo = repo;
	}

}