package com.LibraryManegementSystem.security.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.Exception.OrderNotFoundException;
import com.LibraryManegementSystem.models.Books;
import com.LibraryManegementSystem.models.BooksIssued;
import com.LibraryManegementSystem.models.BooksOrder;
import com.LibraryManegementSystem.repository.BookRepository;
import com.LibraryManegementSystem.repository.BooksIssuedRepository;
import com.LibraryManegementSystem.repository.BooksOrderRepository;

@Service
public class BooksOrderService {
	private static final Logger log = LoggerFactory.getLogger(BooksOrderService.class);
	@Autowired
	BooksOrderRepository repo;

	@Autowired
	BookRepository brepo;


	@Autowired
	private BooksIssuedRepository irepo;
	
	
	

	public int placeBooksOrder(int id, int userid, BooksOrder book) throws OrderNotFoundException {
		BooksOrder booksorder = new BooksOrder();
		LocalDate date = LocalDate.now();
		booksorder.setOrderDate(date);
		booksorder.setOrderStatus("Pending");
		booksorder.setQuantity(1);
		booksorder.setUserid(userid);
		Books books = brepo.findById(id).get();
		books.setQuantity(books.getQuantity() >1 ? books.getQuantity()-1: book.getQuantity()   );
		
		
		BooksIssued booksIssued = new BooksIssued();
		booksIssued.setDueDate(date.plusDays(15));
		booksIssued.setIssueDate(date);
		booksIssued.setQuantity(1);
		irepo.save(booksIssued);
		booksorder.setBooks(books);
		log.info("Book Order In Processing...");
		try {
			repo.save(booksorder);
			log.info("Order Placed!!!");
			return 1;
		} catch (Exception e) {
			throw new OrderNotFoundException("ordered book does not exist");
		}
	}

	public int cancleOrder(int orderiId) {
		log.info("Cancelling Order...");
		try {
			repo.deleteById(orderiId);
			log.info("Order Cancelled!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public int updateOrder(int orderId, BooksOrder order) throws OrderNotFoundException {

		BooksOrder BooksOrder = repo.findById(orderId).get();
		BooksOrder.setQuantity(order.getQuantity());
		BooksOrder.setOrderStatus(order.getOrderStatus());
		BooksOrder.setOrderDate(order.getOrderDate());
		BooksOrder.setBooks(order.getBooks());

		log.info("Updating Order...");
		try {
			repo.save(BooksOrder);
			log.info("Order Updated!!");
			return 1;
		} catch (Exception e) {
			throw new OrderNotFoundException("Order Book does not exist");
		}
	}

	public int confirmOrder(int orderId, BooksOrder order) throws OrderNotFoundException {

		BooksOrder BooksOrder = repo.findById(orderId).get();
		BooksOrder.setOrderStatus("Ordered");

		log.info("Order placing...");
		try {
			repo.save(BooksOrder);
			log.info("Order Placed!!");
			return 1;
		} catch (Exception e) {
			throw new OrderNotFoundException("Order Book does not exist");
		}
	}

	public List<BooksOrder> viewOrderList() {
		try {
			return (List<BooksOrder>) repo.findAll();
		} catch (Exception e) {
			return null;
		}
	}

	public BooksOrder viewOrderById(int orderId) throws OrderNotFoundException {
		log.info("Fetching Order By Id Number: " + orderId + "...");
		try {
			BooksOrder bo = repo.findById(orderId).get();
			log.info("Fetched Order By ID Number: " + orderId + "!!");
			return bo;

		} catch (Exception e) {
			throw new OrderNotFoundException("Order Book with Id " + orderId + " does not exist");
		}
	}
	public BooksOrderService(BooksOrderRepository repo2) {
		super();
	}
}
