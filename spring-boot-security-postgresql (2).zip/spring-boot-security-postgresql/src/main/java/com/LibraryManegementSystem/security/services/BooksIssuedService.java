package com.LibraryManegementSystem.security.services;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.Exception.BookNotFoundException;
import com.LibraryManegementSystem.models.Books;
import com.LibraryManegementSystem.models.BooksIssued;
import com.LibraryManegementSystem.repository.BookRepository;
import com.LibraryManegementSystem.repository.BooksIssuedRepository;

@Service
public class BooksIssuedService {

	private static final Logger log = LoggerFactory.getLogger(BooksIssuedService.class);

	@Autowired
	BookRepository brepo;

	@Autowired
	private BooksIssuedRepository rrepo;

	public int addIssuedBooks(int id, BooksIssued issued) throws BookNotFoundException {
		BooksIssued booksIssued = new BooksIssued();
		Books books = brepo.findById(id).get();
log.info("Issuing Book...");
		try {
			rrepo.save(issued);
			log.info("Book Issued!!");
			return 1;
		} catch (Exception e) {
			throw new BookNotFoundException("Unable to get Book");
		}
	}

	public int updateIssuedBookDetails(BooksIssued booksIssued) throws BookNotFoundException {
		log.info("Updating Issued Book...");
		try {
			rrepo.save(booksIssued);
			log.info("Updated Issued Book");
			return 1;
		} catch (Exception e) {
			throw new BookNotFoundException("Book does not exist");
		}
	}

	public int deleteIssuedBooks(int bookid) throws BookNotFoundException {
		log.info("Cancelling Issued Book...");
		try {
			rrepo.deleteById(bookid);
			log.info("Cancelled Issued Book...");
			return 1;
		} catch (Exception e) {
			throw new BookNotFoundException("Book does not exist");
		}
	}

	public List<BooksIssued> viewBooksIssuedList() {
		try {
			return (List<BooksIssued>) rrepo.findAll();
		} catch (Exception e) {
			return Collections.emptyList();
		}
	}

	public BooksIssuedService(BooksIssuedRepository repo) {
		super();
	}
}