package com.LibraryManegementSystem.models;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class BooksOrder {

	@Id
	@Column
    @GeneratedValue(strategy = GenerationType.AUTO)
	int orderid;
	 
	@OneToOne
	private Books books;
	
	@Column
	private int quantity;
	
	@Column
	private LocalDate orderDate;
	
	@Column
	private String orderStatus;

	@Column
	private int userid;

	public BooksOrder() {
		super();
	}

	public BooksOrder(int orderid, Books books, int quantity, LocalDate orderDate, String orderStatus, int userid) {
		super();
		this.orderid = orderid;
		this.books = books;
		this.quantity = quantity;
		this.orderDate = orderDate;
		this.orderStatus = orderStatus;
		this.userid = userid;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public Books getBooks() {
		return books;
	}

	public void setBooks(Books books) {
		this.books = books;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	
	
}
