package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.Exception.OrderNotFoundException;
import com.LibraryManegementSystem.models.BooksOrder;
import com.LibraryManegementSystem.security.services.BooksOrderService;

@RestController
@CrossOrigin(origins = "*", maxAge =9000)
@RequestMapping("/api/test")
public class BooksOrderController {

	@Autowired
	BooksOrderService b;
	
	@GetMapping("getorderbooks")
	public List<BooksOrder> viewOrderList() {
		return b.viewOrderList();
	}
	
	@GetMapping("getorderbooks/{orderId}")
	public BooksOrder viewOrderById(@PathVariable int orderId) throws OrderNotFoundException {
		return b.viewOrderById(orderId);
	}
	
	
	@PostMapping("/postorderbooks/{id}/{userid}")
	public int placeBooksOrder(@PathVariable int id , @PathVariable int userid,@RequestBody BooksOrder book) throws OrderNotFoundException
	{
		return b.placeBooksOrder(id,userid,book);
	}
	
	@PutMapping("/putorderbooks/{orderId}")
	public int updateOrder(@PathVariable int orderId, @RequestBody BooksOrder order) throws OrderNotFoundException {
		return b.updateOrder(orderId,order);
	
	}
	
	
	@PutMapping("/placedorder/byid/{orderId}")
	public int orderplaced(@PathVariable int orderId, @RequestBody BooksOrder order) throws OrderNotFoundException {
		return b.confirmOrder(orderId,order);
	}
	
	
	@DeleteMapping("/deletebooksOrder/{orderiId}")
	public int cancleOrder(@PathVariable int orderiId) {
		return b.cancleOrder(orderiId);
	
	}

}
