import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
export default class Publisher extends Component {
 
  constructor(props) {
    super(props);

    this.state = {
        publisherName: "",
        contactno: "",
        email: "",
        address1: "",
        address2: "",
        city: "",
        state: "",
        pincode: "",
      m: [],
    };
  }

  componentDidMount() {
    axios
      .get("http://localhost:8090/api/test/getpublisher", {
        headers: authHeader(),
      })
      .then((response) => {
        this.setState({ m: response.data });
      });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state);
    axios
      .post("http://localhost:8090/api/test/addpublisher",  this.state)
      .then((res) => {
        alert("Publisher Added Succesfully");
        window.location.reload(false);
        console.log("Publisher's Details Registered");
      })
      .catch((error) => {});
  };
  handler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };


  
  deletepublisher = (publishedrId) => {
    console.log(publishedrId);
    axios
    .delete(`http://localhost:8090/api/test/deletepublisher/${publishedrId}`, {
        headers: authHeader(),
      })      
    .then(
        (response) => {
          window.location.reload(false);
          alert("Publisher's Details Deleted");
        },
        (error) => {
          alert("Operation failed");
        }
      );
  };
 
  render() {
    
    return (
      <>
        <div className="regi">
        <h3 style={{textAlign:"center"}}>Available Publishers</h3>
          <form>
            <div className="row justify-content-md-center">
              <div className="col ">
                <br/>
                    <div className="row">
                    <input  className="col" type="text" placeholder="Publisher Name" name="publisherName" variant="outlined"  onChange={this.handler}  value={this.state.publisherName}/>
                    <input  className="col" type="text" placeholder="Contact Number" name="contactno" variant="outlined"  onChange={this.handler} value={this.state.contactno}/>
                    <input  className="col" type="text" placeholder="Email" name="email" variant="outlined"  onChange={this.handler}  value={this.state.email}/>
                    <input  className="col" type="text" placeholder="Address 1" name="address1" variant="outlined"  onChange={this.handler}  value={this.state.address1}/>
                    </div> 
                    <div className="row">
                    <input  className="col" type="text" placeholder="Address 2" name="address2" variant="outlined"  onChange={this.handler}  value={this.state.address2}/>
                    <input  className="col" type="text" placeholder="City" name="city" variant="outlined"  onChange={this.handler}  value={this.state.city}/>
                    <input  className="col" type="text" placeholder="State" name="state" variant="outlined"  onChange={this.handler}  value={this.state.state}/>
                    <input  className="col" type="number" placeholder="PinCode" name="pincode" variant="outlined"  onChange={this.handler}  value={this.state.pincode}/>
                    </div>
              </div>
            </div>
            <div class="text-center" id="btns">
              <button type="button" class="btn btn-primary" onClick={this.handleSubmit}>Add Publisher</button>
            </div>
          </form>
        </div>
        <div>
          <div>
            <table className="table table-striped">
              <thead className="thead-dark">
                <tr>
                <th scope="col">Publisher Id</th>
                  <th scope="col">Publisher Name</th>
                  <th scope="col">Contact No</th>
                  <th scope="col"> Email </th>
                  <th scope="col"> Address 1 </th>
                  <th scope="col"> Address 2 </th>
                  <th scope="col">City </th>
                  <th scope="col"> State </th>
                  <th scope="col"> Pincode </th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {this.state.m.map((c) => (
                  
                  <tr key={c.publisherId}>
                    <td>{c.publishedrId}</td>
                <td>{c.publisherName} </td>
                <td>{c.contactno}</td>
                <td>{c.email}</td>
                <td>{c.address1}</td>
                <td>{c.address2}</td>
                <td>{c.city}</td>
                <td>{c.state}</td>
                <td>{c.pincode}</td>
                    <td>
                      <button type="button" class="btn btn-danger" onClick={() => {this.deletepublisher(c.publishedrId);}}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  }
}
