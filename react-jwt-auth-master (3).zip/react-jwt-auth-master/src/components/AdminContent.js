import React, { Component } from "react";
import { Switch, Route,Link } from "react-router-dom";
import Users from "./Users";
export default class AdminContent extends Component {
  render() {
    return (
      <>
      <div>
        <div class="flex-container">
          <div class="flex-left">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th scope="col">
                    <h3 style={{marginLeft: "55px"}}>Content</h3>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <Link to={"/users"}><th scope="row">Users</th></Link>
                </tr>
                <tr>
                  <th scope="row">Books</th>
                </tr>
                <tr>
                  <th scope="row">Order</th>
                </tr>
                <tr>
                  <th scope="row">Publishers</th>
                </tr>
                <tr>
                  <th scope="row">Damaged Books</th>
                </tr>
                <tr>
                  <th scope="row">Feedback</th>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="flex-right">
            right box
            <Switch>
              <Route exact path="/users" component={Users} />
            </Switch>
          </div>

        </div>
        </div>
      </>
    );
  }
}