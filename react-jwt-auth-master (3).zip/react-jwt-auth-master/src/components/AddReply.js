import React, { useState } from "react";
import axios from "axios";
import { useHistory, useParams } from "react-router-dom";

function AddReply() {
  let history = useHistory();
  const { id } = useParams();
  console.log(id);
  const [com, setComment] = useState({
    comments: "",
  });

  const { comments } = com;
  const onInputChange = (e) => {
    console.log(e);
    setComment({ ...com, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:8090/api/test/updatefeedback/${id}`, com);
    history.push("/feedback");
  };

  return (
    <div>
      <form>
        <textarea 
          style={{ width: "100%", height: "150px" }}
          type="text"
          className="form-control"
          value={comments}
          name="comments"
          onChange={(e) => onInputChange(e)}
          >  </textarea>
        <br></br>
        <div class="text-center">
          <button
            id="bt"
            type="button"
            class="btn btn-primary "
            onClick={(e) => onSubmit(e)}
          >
            Add Comment
          </button>
        </div>
      </form>
    </div>
  );
}

export default AddReply;
