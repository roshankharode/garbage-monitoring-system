import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
export default class IssuedBook extends Component {
  constructor(props) {
    super(props);
    this.state = {
      m: [],
    };
  }

  componentDidMount() {
    axios
      .get("http://localhost:8090/api/test/getissuedbooks", { headers: authHeader() })
      .then((response) => {
        this.setState({ m: response.data });
      });
  }

  
  render() {
    
    return (
      <>
        <div>
          <div>
          <h3 style={{textAlign:"center"}}>Issued Books List</h3>
            <table className="table table-striped">
              <thead className="thead-dark">
                <tr>
                <th scope="col">Issued Id</th>
                  <th scope="col">Issue Date</th>
                  <th scope="col">Quantity</th>
                  <th scope="col"> Due Date </th>
                  <th scope="col"> Return Book </th>
                </tr>
              </thead>
              <tbody>
                {this.state.m.map((c) => (
                  
                  <tr key={c.issueId}>
                <td>{c.issueId}</td>
                <td>{c.issueDate} </td>
                <td>{c.quantity}</td>
                <td>{c.dueDate}</td>
                <td>{c.bookid}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  }
}
