import React, { Component } from 'react'
import { useHistory, useParams } from "react-router-dom";

import axios from "axios";
import authHeader from "../services/auth-header";
import { withRouter } from "react-router";
class Rkk extends Component {
    constructor(props){
        super();
        this.state ={
            feedback:[],
        };
      }
      
      componentDidMount() {
        const id = this.props.match.params.id;
        this.fetchData(id);
        axios
          .get(      `http://localhost:8090/api/test/getfeebackby/${id}`, {
            headers: authHeader(),
          })
          .then((response) => {
            this.setState({ feedback: response.data });
          });
      }

    fetchData = id => {
      console.log(id);
    };
  render() {
    return <>
     <div>
       <h3 style={{textAlign:"center"}}>Feedback List</h3>
            <table className="table table-striped">
              <thead className="thead-dark">
                <tr>
                <th scope="col">Feedback Id</th>
                  <th scope="col">Feedback Date</th>
                  <th scope="col">Description</th>
                  <th scope="col"> Rating </th>
                  <th scope="col"> Comments</th>
                </tr>
              </thead>
              <tbody>
                {this.state.feedback.map((c) => (
                  
                  <tr key={c.feedbackid}>
                <td>{c.feedbackDate} </td>
                <td>{c.description}</td>
                <td>{c.rating}</td>
                <td>{c.comments}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div></>
  };
}
export default  withRouter(Rkk)