import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
export default class Users extends Component {
  constructor(props) {
    super(props);

    this.state = {
      cust: [],
    };
  }
  
  componentDidMount() {
    axios
      .get("http://localhost:8090/api/users", { headers: authHeader() })
      .then((response) => {
        this.setState({ cust: response.data });
      });
  }

 deleteUser = (id) =>{
    axios.delete( "http://localhost:8090/api/users/" + id ,  { headers: authHeader() }).then(
        (response) =>{
          alert("User Removed");
          window.location.reload(false);
            this.setState({
                user : this.state.cust.filter(cust=>cust.id !==id)
            });
        }, (error) =>{
          window.location.reload(false);
            alert("Operation failed");
        }
    )
 }
 
 cancleSub = (id) => {
  axios
    .put("http://localhost:8090/api/auth/cancleSubcriptionby/" + id ,  { headers: authHeader() })
    .then(
      (response) => {
        alert("Subcription Canceled");
        window.location.reload(false);
      },
      (error) => {
        window.location.reload(false);
        alert("Operation failed");
      }
    );
};

  render() {
    return (
      <div>
        <h3 style={{textAlign:"center"}}>Available Users</h3>
        <table className="table table-striped">
          <thead className="thead-dark">
            <tr>
              <th scope="col">Id</th>
              <th scope="col">User Name</th>
              <th scope="col">Last Name</th>
              <th scope="col"> Email </th>
              <th scope="col"> DOB </th>
              <th scope="col"> Mobile Number </th>
              <th scope="col"> subscription Date  </th>
              <th scope="col"> Subcription Status </th>
              <th scope="col"> sub_expire Date  </th>
              <th scope="col">Cancle Subcription</th>
              <th scope="col">Remove User</th>
              
            </tr>
          </thead>
          <tbody>
            {this.state.cust.map((c) => (
              <tr key={c.id}>
                <td>{c.id}</td>
                <td>{c.username} </td>
                <td>{c.lastName}</td>
                <td>{c.email}</td>
                <td>{c.date_of_birth}</td>
                <td>{c.mobileno}</td>
                <td>{c.subscription_date}</td>
                <td>{c.subscription_status}</td>
                <td>{c.sub_expire_date}</td>
                <td>
                <button type="button"  class="btn btn-warning "onClick={() => {this.cancleSub(c.id);}}>Cancle Sub </button>
                </td>
                <td>
                    <button  class="btn btn-danger " onClick={()=>{this.deleteUser(c.id)}}>Unverified</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
