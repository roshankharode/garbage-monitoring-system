import React, { useState, useEffect } from "react";
import axios from "axios";
import { useHistory, useParams } from "react-router-dom";
function UpdateBook() {
  let history = useHistory();
  const { id } = useParams();
  const [books, setBooks] = useState({
    title: "",
    subject: "",
    published_year: "",
    isbn_code: "",
    quantity: "",
    shelf_details: "",
  });

  const { title, subject, published_year, isbn_code, quantity, shelf_details } =
    books;
  const onInputChange = (e) => {
    setBooks({ ...books, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:8090/api/test/putbooks/${id}`, books);
    history.push("/books");
  };

  useEffect(() => {
    loadBook();
  }, []);

  const loadBook = async () => {
    const result = await axios.get(
      `http://localhost:8090/api/test/getbooks/${id}`
    );
    setBooks(result.data);
  };

  return (
    <div  className="regi" id="upimg">
      <form onSubmit={(e) => onSubmit(e)}>
        <div className="row">
          <div className="col">
            <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder="title "
              value={title}
              name="title"
              onChange={(e) => onInputChange(e)}
            />

            <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder="subject "
              value={subject}
              name="subject"
              onChange={(e) => onInputChange(e)}
            />
            <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder=" isbnCode"
              value={isbn_code}
              name="isbn_code"
              onChange={(e) => onInputChange(e)}
            />
          </div>
          <div className="col">
            <input
              style={{ marginBottom: "9px" }}
              type="Number"
              className="form-control"
              placeholder="publishedYear  "
              value={published_year}
              name="published_year"
              onChange={(e) => onInputChange(e)}
            />

            <input
              style={{ marginBottom: "9px" }}
              type="Number"
              className="form-control"
              placeholder=" quantity "
              value={quantity}
              name="quantity"
              onChange={(e) => onInputChange(e)}
            />

            <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder="  shelfDetails "
              value={shelf_details}
              name="shelf_details"
              onChange={(e) => onInputChange(e)}
            />
          </div>
        </div>
        <div class="text-center" id="btns">
          <button
            onClick={(e) => onSubmit(e)}
            type="button"
            class="btn btn-primary "
          >
            update Book
          </button>
        </div>
      </form>
    </div>
  );
}

export default UpdateBook;
