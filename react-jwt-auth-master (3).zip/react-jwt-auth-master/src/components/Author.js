import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
export default class Author extends Component {
  constructor(props) {
    super(props);

    this.state = {
        firstName: "",
        lastName: "",
        email: "",
        contactno: "",
      m: [],
    };
  }

  componentDidMount() {
    axios
      .get("http://localhost:8090/api/test/getauthorlist", { headers: authHeader() })
      .then((response) => {
        this.setState({ m: response.data });
      });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state);
    axios
      .post("http://localhost:8090/api/test/addauthor", this.state, { headers: authHeader() })
      .then((res) => {
        alert("Author added succesfully");
        window.location.reload(false);
        console.log("Author's Details Registered");
      })
      .catch((error) => {});
  };
  handler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  
  deleteauthor = (authorid) => {
    console.log(authorid);
    axios
    .delete(`http://localhost:8090/api/test/deleteauthor/${authorid}`, { headers: authHeader() })      
    .then(
        (response) => {
          window.location.reload(false);
          alert("Author's Details Deleted");
        },
        (error) => {
          alert("Operation failed");
        }
      );
  };
  render() {
    
    return (
      <>
        <div className="regi">
          <form>
          <h3 style={{textAlign:"center"}}>Author List</h3>
            <div className="row justify-content-md-center">
              <div className="col ">
                <br/>
                <div className="row">
                    <input  className="col" type="text" placeholder="first Name" name="firstName" variant="outlined"  onChange={this.handler}  value={this.state.firstName}/>
                    <input  className="col" type="text" placeholder="last Name" name="lastName" variant="outlined"  onChange={this.handler} value={this.state.lastName}/>
                    <input  className="col" type="text" placeholder="Email" name="email" variant="outlined"  onChange={this.handler}  value={this.state.email}/>
                    <input  className="col" type="text" placeholder="contact number" name="contactno" variant="outlined"  onChange={this.handler}  value={this.state.contactno}/>
                </div>
              </div>
            </div>
            <div class="text-center" id="btns">
            <button type="button" class="btn btn-primary" onClick={this.handleSubmit}>Add Author</button>
            </div>
          </form>
        </div>
        <div>
          <div>
            <table className="table table-striped">
              <thead className="thead-dark">
                <tr>
                <th scope="col">Author Id</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col"> Email </th>
                  <th scope="col"> Contact No </th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {this.state.m.map((c) => (
                  
                  <tr key={c.authorId}>
                <td>{c.authorId}</td>
                <td>{c.firstName} </td>
                <td>{c.lastName}</td>
                <td>{c.email}</td>
                <td>{c.contactno}</td>
                    <td>
                    <button type="button" class="btn btn-danger" onClick={() => {this.deleteauthor(c.authorId);}}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  }
}
