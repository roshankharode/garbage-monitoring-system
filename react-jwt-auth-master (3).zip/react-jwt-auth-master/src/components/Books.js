import React, { Component, useRef } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
import { Link } from "react-router-dom";
export default class Books extends Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "",
      subject: "",
      author: "",
      publisher: "",
      published_year: "",
      quantity: "",
      isbn_code: "",
      shelf_details: "",
      B: [],
      p: [],
      A: [],
    };
  }

  componentDidMount() {
    axios
      .get("http://localhost:8090/api/test/getbooks", { headers: authHeader() })
      .then((response) => {
        this.setState({ B: response.data });
      });
    axios
      .get("http://localhost:8090/api/test/getpublisher", {
        headers: authHeader(),
      })
      .then((response) => {
        this.setState({ p: response.data });
      });
    axios
      .get("http://localhost:8090/api/test/getauthorlist", {
        headers: authHeader(),
      })
      .then((response) => {
        this.setState({ A: response.data });
      });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state);
    axios
      .post("http://localhost:8090/api/test/postbooks", this.state)
      .then((res) => {
        alert("Added Succesfully");
        window.location.reload(false);
        console.log("User Registered");
      })
      .catch((error) => {});
  };

  handler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  pub = (e) => {
    this.setState({ publisher: e.target.value });
  };
  author = (e) => {
    this.setState({ author: e.target.value });
  };

  deletebook = (bookId) => {
    axios
      .delete("http://localhost:8090/api/test/deletebooks/" + bookId, {
        headers: authHeader(),
      })
      .then(
        (response) => {
          alert("Book Deleted");
          window.location.reload(false);
        },
        (error) => {
          window.location.reload(false);
          alert("Operation failed");
        }
      );
  };

  render() {
    return (
      <div>
        <h3 style={{ textAlign: "center" }} id="bookback">All Books</h3>
        <div className="regi">
          <form>
            <div className="row">
              <div className="col">
                <input
                  style={{ marginBottom: "9px" }}
                  type="text"
                  className="form-control"
                  placeholder="Title "
                  value={this.state.title}
                  name="title"
                  onChange={this.handler}
                />
                <input
                  style={{ marginBottom: "9px" }}
                  type="text"
                  className="form-control"
                  placeholder="Subject "
                  value={this.state.subject}
                  name="subject"
                  onChange={this.handler}
                />
                <input
                  style={{ marginBottom: "9px" }}
                  type="text"
                  className="form-control"
                  placeholder=" Shelf Details "
                  value={this.state.shelf_details}
                  name="shelf_details"
                  onChange={this.handler}
                />
                <label for="author" id="opt">
                  Select Author
                </label>
                <select
                  onChange={this.author}
                  name="author"
                  className="form-control"
                >
                  {this.state.A.map((o) => (
                    <option value={o.firstName}>{o.firstName}</option>
                  ))}
                </select>
              </div>

              <div className="col">
                <input
                  style={{ marginBottom: "9px" }}
                  type="Number"
                  className="form-control"
                  placeholder="Published Year  "
                  value={this.state.published_year}
                  name="published_year"
                  onChange={this.handler}
                />

                <input
                  style={{ marginBottom: "9px" }}
                  type="text"
                  className="form-control"
                  placeholder=" Isbn Code"
                  value={this.state.isbn_code}
                  name="isbn_code"
                  onChange={this.handler}
                />

                <input
                  style={{ marginBottom: "9px" }}
                  type="Number"
                  className="form-control"
                  placeholder="Quantity "
                  value={this.state.quantity}
                  name="quantity"
                  onChange={this.handler}
                />

                <label for="publishers" id="opt">
                  {" "}
                  Select Publisher
                </label>
                <select
                  onChange={this.pub}
                  id="publishers"
                  className="form-control"
                >
                  {this.state.p.map((o) => (
                    <option value={o.publisherName}>{o.publisherName}</option>
                  ))}
                </select>
              </div>
            </div>
            <div class="text-center" id="btns">
              <button
                type="button"
                class="btn btn-primary "
                onClick={this.handleSubmit}
              >
                Add Book
              </button>
            </div>
          </form>
        </div>
        <div>
          <div>
            <table className="table table-striped">
              <thead class="table-primary">
                <tr>
                  <th scope="col">bookId</th>
                  <th scope="col">title</th>
                  <th scope="col">subject</th>
                  <th scope="col"> author </th>
                  <th scope="col"> publisher </th>
                  <th scope="col"> publishedYear </th>
                  <th scope="col">isbnCode </th>
                  <th scope="col"> quantity </th>
                  <th scope="col"> shelfDetails </th>
                  <th scope="col"> Update</th>
                  <th scope="col"> Delete</th>
                </tr>
              </thead>
              <tbody>
                {this.state.B.map((book) => (
                  <tr key={book.bookid}>
                    <td>{book.bookid}</td>
                    <td>{book.title} </td>
                    <td>{book.subject}</td>
                    <td>{book.author}</td>
                    <td>{book.publisher}</td>
                    <td>{book.published_year}</td>
                    <td>{book.isbn_code}</td>
                    <td>{book.quantity}</td>
                    <td>{book.shelf_details}</td>
                    <td>
                      <Link
                        to={`/updatebook/${book.bookid}`}
                        class="btn btn-info "
                      >
                        Update
                      </Link>
                    </td>
                    <td>
                      <button
                        type="button"
                        class="btn btn-danger "
                        onClick={() => {
                          this.deletebook(book.bookid);
                        }}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}
