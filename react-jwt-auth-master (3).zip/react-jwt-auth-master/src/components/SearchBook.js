import React from 'react';
import axios from 'axios';
import { useEffect,useState } from 'react';
import authHeader from '../services/auth-header';

function SearchBook(){

    var[search,setSearch]=useState([]);
    var[record,setRecord]=useState([]);
    var i=1;
    
    
    const loadRecords=async()=>{
        axios.get(`http://localhost:8090/api/test/getbooksby/title/${record}` ,{headers:authHeader,})
        .then(response=>{
            setSearch(response.data);
        });
    }

    useEffect(()=>{
        loadRecords();
    },[]);
    
    
    const searchRecords=()=>{
        axios.get(`http://localhost:8090/api/test/getbooksby/title/${record}` ,{headers:authHeader,})
        .then(response=>{
             setSearch(response.data);
        });
    }

    return(
        <>
        <div class="container">
            <h4 className="text-center text-success mt-5"><b>Search Books by Title</b></h4>
            <div class="input-group- mb-4 mt-3">
                <div class="form-outline">
                    <input type="text" id="form1" onChange={(e)=>setRecord(e.target.value)} class="form-control" placeholder='Search'></input>
                </div>
                <br></br>
                <button type="button" onClick={searchRecords} class="btn btn-success" style={{marginLeft:"480px"}}>
                    Search Book
                </button>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th>Book Id</th>
                    <th>Title</th>
                    <th>Subject</th>
                    <th>Author</th>
                    <th>Publisher</th>
                    <th>Published Year</th>
                    <th>Isbn Code</th>
                    <th>Quantity</th>
                    <th>Shelf Details</th>
                    </tr>
                </thead>
                <tbody>
                    {search.map((c)=>
                    <tr>
                        <td>{i++}</td>
                        <td>{c.title}</td>
                        <td>{c.subject}</td>
                        <td>{c.author}</td>
                        <td>{c.publisher}</td>
                        <td>{c.published_year}</td>
                        <td>{c.isbn_code}</td>
                        <td>{c.quantity}</td>
                        <td>{c.shelf_details}</td>
                    </tr>
                    )}
                </tbody>
            </table>
        </div>
        </>
    );
}
export default SearchBook;