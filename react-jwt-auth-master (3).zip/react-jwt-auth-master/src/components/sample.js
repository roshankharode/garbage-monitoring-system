import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
import AuthService from "../services/auth.service";

export default class sample extends Component {
  constructor(props) {
    super(props);
    this.state = {
      AllPackages: [],
      currentUser: { currentUser: ""},
    };
  }

  componentDidMount() {
    const currentUser = AuthService.getCurrentUser();
    if (!currentUser) this.setState({ redirect: "/home" });
    this.setState({ currentUser: currentUser, userReady: true });
    axios
      .get("http://localhost:8090/api/packages/viewAllPackages", { headers: authHeader() })
      .then((response) => {
        this.setState({ AllPackages: response.data });
      });
  }

  bookpackage = ([packageId, id]) => {
    console.log(packageId);
    console.log(id);
    axios
      .post(
        `http://localhost:8090/api/booking/addBooking/${packageId}/${id}`,this.state, { headers: authHeader() },)
      .then((res) => {
        alert("Order Succesfully");
        window.location.reload(false);
      })
      .catch((error) => {
        alert("Operation failed");
      });
  };

  render() {
    const { currentUser } = this.state;
    return (
      <div className="container my-4"  id="imgbook">
        <div className="row">
          {this.state.AllPackages.map((element) => {
            return (
              
              <div className="col-md-3" key={element.packageId}>
                <div className="card">
                <div className="card-body">
                  <h4 className="card-title">{element.packageName} </h4>
                  <p className="card-subtitle mb-1 text-muted">
                  Description : {element.description}{" "}
                  </p>
                  <p className="card-subtitle mb-1 text-muted">
                  Fare : {element.fare}{" "}
                  </p>
                  <button
                    type="btn"
                    className="btn btn-primary"
                    onClick={() => {
                      this.bookpackage([element.packageId, currentUser.id]);
                    }}
                    style={{marginLeft:"80px",marginBottom:"-30px",marginTop:"20px"}}>
                    Book
                  </button>
                    </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
}
