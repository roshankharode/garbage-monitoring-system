package com.LoanProcessing.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.LoanProcessing.Exception.IdNotFoundException;
import com.LoanProcessing.Exception.LoanNotFoundException;
import com.LoanProcessing.Exception.NameNotFoundException;
import com.LoanProcessing.Model.Loan;
import com.LoanProcessing.Service.LoanService;

@RestController
public class LoanController {
	
	@Autowired
	private LoanService loanService;
	
	//post Methods
		@PostMapping("/loanplan")
		public Loan addLoanPlan(@Valid @RequestBody Loan loan) {
			return loanService.addLoanPlan(loan);
		}
		
		
		//Get Methods
		@GetMapping("/loanplans")
		public List<Loan> getAllLoanPlan(){
			return loanService.getAllLoanPlan();
		}
		 

		 @GetMapping("/loanname/{loanname}")
		 public List<Loan> getLoanByName(@Valid @PathVariable("loanname") String loanName) throws NameNotFoundException {
			 return loanService.getLoanPlanByName(loanName);
		 }
		 
		 //Put Method
		 @PutMapping("/modify_loan")
			public Loan updateLoanPlan(@Valid @RequestBody Loan loan)  throws LoanNotFoundException {
			 return loanService.updateLoanPlan(loan);
		 }
		 
		 //Delete Method
		 @DeleteMapping("/loan/{loanid}")
		 public String deleteLoanById(@Valid @PathVariable("loanid") Integer loanId) throws IdNotFoundException{
			 return loanService.deleteLoanPlanById(loanId);
		 }

}
