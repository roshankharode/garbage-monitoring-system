package com.LoanProcessing.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.LoanProcessing.Exception.IdNotFoundException;
import com.LoanProcessing.Exception.LoanNotFoundException;
import com.LoanProcessing.Exception.NameNotFoundException;

@RestControllerAdvice
public class LoanProcessingControllerAdvice {

	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<String> idNotFoundExceptionHandler(IdNotFoundException ie){
		
		return new ResponseEntity<String>(ie.getMessage(),HttpStatus.BAD_REQUEST); 
	} 
	
	@ExceptionHandler(NameNotFoundException.class)
	public ResponseEntity<String> nameNotFoundExceptionHandler(NameNotFoundException ne){
		
		return new ResponseEntity<String>(ne.getMessage(),HttpStatus.BAD_REQUEST); 
	} 
	
	@ExceptionHandler(LoanNotFoundException.class)
	public ResponseEntity<String> LoanNotFoundExceptionHandler(LoanNotFoundException le){
		
		return new ResponseEntity<String>(le.getMessage(),HttpStatus.BAD_REQUEST); 
	} 
	
	
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String,String> handleValidationsExceptions(MethodArgumentNotValidException e){
		Map<String,String> errors = new HashMap<String,String>();
		e.getBindingResult().getAllErrors().forEach((error)->{
			String fieldName = ((FieldError)error).getField();
			String errorMsg = error.getDefaultMessage();
			errors.put(fieldName, errorMsg);
		});
		return errors;
	}
}
