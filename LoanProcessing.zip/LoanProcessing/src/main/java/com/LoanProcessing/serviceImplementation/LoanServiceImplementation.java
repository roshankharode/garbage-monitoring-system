package com.LoanProcessing.serviceImplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LoanProcessing.Exception.IdNotFoundException;
import com.LoanProcessing.Exception.LoanNotFoundException;
import com.LoanProcessing.Exception.NameNotFoundException;
import com.LoanProcessing.Model.Loan;
import com.LoanProcessing.Repository.LoanRepository;
import com.LoanProcessing.Service.LoanService;

@Service
public class LoanServiceImplementation implements LoanService {
	
	@Autowired
	private LoanRepository loanRepository;

	@Override
	public Loan addLoanPlan(Loan loan) {
		return  loanRepository.save(loan);
	}

	@Override
	public Loan updateLoanPlan(Loan loan) throws LoanNotFoundException{
		this.loanRepository.findById(loan.getLoanId()).orElseThrow(() -> new LoanNotFoundException("Can not update! No loan plan found with Id: " + loan.getLoanId()));
		Optional<Loan> existingLoanOptional = loanRepository.findById(loan.getLoanId());
	    Loan updateLoan = existingLoanOptional.get();
		updateLoan.setLoanName(loan.getLoanName());
		updateLoan.setAmount(loan.getAmount());
		updateLoan.setInterestRate(loan.getInterestRate());
		return loanRepository.save(updateLoan);
	}

	@Override
	public String deleteLoanPlanById(Integer loanId) throws IdNotFoundException {
		 this.loanRepository.findById(loanId).orElseThrow(() -> new IdNotFoundException("No loan plan found with Id: " + loanId));
		loanRepository.deleteById(loanId);
		return "Loan plan is deleted successfully";
	}

	@Override
	public List<Loan> getLoanPlanByName(String loanName) throws NameNotFoundException {
		List<Loan> foundLoanPlanByName = this.loanRepository.findByLoanName(loanName);
		if (foundLoanPlanByName.isEmpty())
			throw new NameNotFoundException("No loan plan found with loan name: " + loanName);

		return foundLoanPlanByName;
	}

	@Override
	public List<Loan> getAllLoanPlan() {
		return loanRepository.findAll();
	}

}
