package com.LoanProcessing.serviceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LoanProcessing.Repository.LADTeamRepository;
import com.LoanProcessing.Service.LADTeamService;

@Service
public class LADTeamServiceImplementation implements LADTeamService {
	
	@Autowired 
	private LADTeamRepository ladTeamRepository;

}
