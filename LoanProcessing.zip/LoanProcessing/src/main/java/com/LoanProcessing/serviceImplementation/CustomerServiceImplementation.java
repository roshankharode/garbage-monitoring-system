package com.LoanProcessing.serviceImplementation;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LoanProcessing.Model.Customer;
import com.LoanProcessing.Model.Loan;
import com.LoanProcessing.Repository.CustomerRepository;
import com.LoanProcessing.Repository.LoanRepository;
import com.LoanProcessing.Service.CustomerService;


@Service
public class CustomerServiceImplementation implements CustomerService{
	
	@Autowired 
	CustomerRepository customerRepository;
	@Autowired
	LoanRepository loanRepository;

	@Override
	public Customer addLoanApplication(Customer customer, Integer loanId) {
		Optional<Loan> optionalLoan = loanRepository.findById(loanId);
		customer.setLoan(optionalLoan.get());
		return customerRepository.save(customer);
	}

	@Override
	public List<Customer> showAllLoanApplication() {
		return customerRepository.findAll();
	}

}
