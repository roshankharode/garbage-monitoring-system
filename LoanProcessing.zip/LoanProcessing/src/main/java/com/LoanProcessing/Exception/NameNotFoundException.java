package com.LoanProcessing.Exception;

public class NameNotFoundException extends Exception{
	
	public NameNotFoundException(String msg) {
		super(msg);
	}

}
