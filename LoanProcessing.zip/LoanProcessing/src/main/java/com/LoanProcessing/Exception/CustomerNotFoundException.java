package com.LoanProcessing.Exception;

public class CustomerNotFoundException extends Exception {
	
	String msg;
	public CustomerNotFoundException(String msg) {
		super(msg);
		this.msg = msg;
	}
	
}
