package com.LoanProcessing.Exception;

public class IdNotFoundException extends Exception {
	
	public IdNotFoundException(String msg) {
		super(msg);
	}

}
