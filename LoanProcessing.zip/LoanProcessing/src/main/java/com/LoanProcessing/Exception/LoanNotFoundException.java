package com.LoanProcessing.Exception;

public class LoanNotFoundException extends Exception {


	public LoanNotFoundException(String msg) {
		super(msg);
	}

}
