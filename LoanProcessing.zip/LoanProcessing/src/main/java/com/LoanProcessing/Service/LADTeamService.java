package com.LoanProcessing.Service;

public interface LADTeamService {

}
