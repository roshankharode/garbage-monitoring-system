package com.LoanProcessing.Service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.LoanProcessing.Model.Customer;

public interface CustomerService {
	
	public Customer addLoanApplication(Customer customer, Integer loanId);
	
	public List<Customer> showAllLoanApplication();

}
