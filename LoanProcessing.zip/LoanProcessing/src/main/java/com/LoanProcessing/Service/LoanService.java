package com.LoanProcessing.Service;

import java.util.List;

import com.LoanProcessing.Exception.IdNotFoundException;
import com.LoanProcessing.Exception.LoanNotFoundException;
import com.LoanProcessing.Exception.NameNotFoundException;
import com.LoanProcessing.Model.Loan;

public interface LoanService {
	
	public Loan addLoanPlan(Loan loan);
	public Loan updateLoanPlan(Loan loan) throws LoanNotFoundException;
	public String deleteLoanPlanById(Integer loanId) throws IdNotFoundException;
	public List<Loan> getLoanPlanByName(String loanName) throws NameNotFoundException;
	public List<Loan> getAllLoanPlan();
	//public Vaccine getVaccineById(Integer vaccineId) throws IdNotFoundException;
	
}
