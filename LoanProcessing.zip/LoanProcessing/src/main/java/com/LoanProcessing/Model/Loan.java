package com.LoanProcessing.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "LoanPlans")
public class Loan {

	@Id
	@GeneratedValue
	private Integer loanId;

	@NotBlank(message = "Name cannot be blank")
	@Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters long.")
	private String loanName;

	@NotNull
	private Integer amount;
	
	@NotNull
	private Integer noOfEMI;

	@NotNull
	private Integer interestRate;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "loan")
	private List<Customer> customer = new ArrayList<>();
	
	public Loan() {

	}


	public Loan(Integer loanId,
			@NotBlank(message = "Name cannot be blank") @Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters long.") String loanName,
			@NotNull Integer amount, @NotNull Integer noOfEMI, @NotNull Integer interestRate, List<Customer> customer) {
		super();
		this.loanId = loanId;
		this.loanName = loanName;
		this.amount = amount;
		this.noOfEMI = noOfEMI;
		this.interestRate = interestRate;
		this.customer = customer;
	}


	public Integer getLoanId() {
		return loanId;
	}


	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}


	public String getLoanName() {
		return loanName;
	}


	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}


	public Integer getAmount() {
		return amount;
	}


	public void setAmount(Integer amount) {
		this.amount = amount;
	}


	public Integer getNoOfEMI() {
		return noOfEMI;
	}


	public void setNoOfEMI(Integer noOfEMI) {
		this.noOfEMI = noOfEMI;
	}


	public Integer getInterestRate() {
		return interestRate;
	}


	public void setInterestRate(Integer interestRate) {
		this.interestRate = interestRate;
	}


	public List<Customer> getCustomer() {
		return customer;
	}


	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}

}
