package com.LoanProcessing.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Admin extends User {
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinTable(name = "AdminToLad")
	private LADTeam ladTeam;
	
	@OneToMany
	@JoinTable(name = "AdminToLoan")
	private List<Loan> loan = new ArrayList<>();
	
	@OneToMany
	@JoinTable(name = "AdminToCustomer")
	private List<Customer> customer = new ArrayList<>();
	

	public Admin() {
		super();
	}


	public Admin(Integer userId, String name, String address, String email, String userName,
			String password) {
		super(userId, name, address, email, userName, password);
		
	}

}