package com.LoanProcessing.Model;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

@Entity
public class LADTeam extends User{
	
@NotNull	
private String designation;
	
	public LADTeam() {
		super();
	}

	public LADTeam(String designation) {
		super();
		this.designation = designation;
	}

	public LADTeam(Integer userId, String name, String address, String email, String userName,
			String password) {
		super(userId, name, address, email, userName, password);
	
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	
	
}
