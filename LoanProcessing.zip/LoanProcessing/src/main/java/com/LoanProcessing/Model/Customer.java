package com.LoanProcessing.Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Customer")
public class Customer {

	@Id
	@GeneratedValue
	private Integer customerId;

	@NotBlank(message = "Name cannot be blank")
	@Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters long.")
	private String custName;

	@NotNull
	private LocalDate dateOfBirth;

	@NotNull
	private Integer age;

	@Digits(fraction = 0, integer = 10, message = "Mobile no. must be 10 digits")
	private Long mobileNumber;

	@Digits(fraction = 0, integer = 11, message = "Account no. must be 11 digits")
	private Long accountNo;

	@NotEmpty(message = "User Email cannot be empty")
	@Email(message = "Email not valid. eg: name@capgi.com")
	private String custEmailId;

	@NotNull
	private Long salary;

	@NotNull
	private Long aadharCard;

	@ManyToOne
	@JoinTable(name = "CustomerToLoan")
	private Loan loan;

	@ManyToOne
	@JoinTable(name = "CustomerToLad")
	private LADTeam ladTeam;

	public Customer() {
		super();
	}

	public Customer(Integer customerId,
			@NotBlank(message = "Name cannot be blank") @Size(min = 3, max = 20, message = "Username must be between 3 and 20 characters long.") String custName,
			@NotNull LocalDate dateOfBirth, @NotNull Integer age,
			@Digits(fraction = 0, integer = 10, message = "Mobile no. must be 10 digits") Long mobileNumber,
			@Digits(fraction = 0, integer = 11, message = "Account no. must be 11 digits") Long accountNo,
			@NotEmpty(message = "User Email cannot be empty") @Email(message = "Email not valid. eg: name@capgi.com") String custEmailId,
			@NotNull Long salary, @NotNull Long aadharCard, Loan loan, LADTeam ladTeam) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.dateOfBirth = dateOfBirth;
		this.age = age;
		this.mobileNumber = mobileNumber;
		this.accountNo = accountNo;
		this.custEmailId = custEmailId;
		this.salary = salary;
		this.aadharCard = aadharCard;
		this.loan = loan;
		this.ladTeam = ladTeam;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	public String getCustEmailId() {
		return custEmailId;
	}

	public void setCustEmailId(String custEmailId) {
		this.custEmailId = custEmailId;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	public Long getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(Long aadharCard) {
		this.aadharCard = aadharCard;
	}


	public void setLoan(Loan loan) {
		this.loan = loan;
	}

	public LADTeam getLadTeam() {
		return ladTeam;
	}

	public void setLadTeam(LADTeam ladTeam) {
		this.ladTeam = ladTeam;
	}

}
